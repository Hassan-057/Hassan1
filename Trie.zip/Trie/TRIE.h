#ifndef TRIE_H
#define TRIE_H
#include<iostream>
#include<string>
#include<fstream>
#include <algorithm>
#include <cstdlib>
#include"Vector.h"
using namespace std;
class node			// node class
{
public:
	node* word[26];			// node array
	char alphabet;			// char data to store character at node
	string mean;			// string to store meaning of word
	Vector<string> synonyms;	// string vector to store synonyms of word
	bool checkend;				// flag to check either word has ended or not
	node()
	{
		for (int i = 0; i < 26; i++)
		{
			word[i] = NULL;
		}
		checkend = false;
		alphabet = '\0';
		mean = "\0";
	}
};

class TRIE
{
public:
	node* root;														// root
	TRIE();
	void CreateDictionary(string str);								//reads file and stores values in tree
	bool FindWord(string);											// finds and returns either the key is present in tree or not
	string FindMeaning(string);										// returns the meaning of key if present in tree
	Vector<string> OutputDescending();								// returns vector of all words in tree in descending order
	Vector<string> OutputAscending();								// returns vector of all words in tree in ascending order
	Vector<string> extract(string, Vector<string> &, node*);		// recursive function to extract or retrive all words from tree
	Vector<string> FindSynonyms(string);							// finds synonyms of key and returns them in string vector
	Vector<string> OutputPrefix(string);							// finds prefix of key
	Vector<string> OutputSmaller(int);								// returns all words smaller then key
	Vector<string> OutputSE(int);									// returns all words smaller and equal then key
	Vector<string> OutputGreater(int);								// returns all words greater then key
	Vector<string> OutputAnagrams(string);							// finds anagarms of key
	Vector<string> OutputSuffix(string);							// finds suffix of key
	Vector<string> CompleteString(string);							// completes the string
	Vector<string> SpellChecker(string);							// checks the speeling and returns the correct ones
};

TRIE::TRIE()						//default constructor
{
	root = new node;
}
void TRIE::CreateDictionary(string str)
{
	fstream file;								//object of fstream
	string line;								//string in which read line from file is stored
	node* last = new node;								//temp node
	file.open(str.c_str());								//opening file
	while (getline(file, line))								//reading file
	{
		node* cur = new node;								//temp node
		cur = root;
		if (line[0] == '-' && line[1] != '-')								//check if the string is word or not
		{
			int len = line.length();							// retrives lenght of line
			int i = 1;
			while (i < len)									// skips '-'
			{
				int idx{};
				if (line[i] >= 'a' && line[i] <= 'z')idx = line[i] - 'a';				// find the suitable alphabet for index
				else if (line[i] >= 'A' && line[i] <= 'Z')idx = line[i] - 'A';
				if (cur->word[idx] == NULL)cur->word[idx] = new node;	// checks if node already exists, if not then creates new one
				cur->word[idx]->alphabet = line[i];					// storing value at suitable node
				cur = cur->word[idx];				// traversing node
				last = cur;
				i++;
			}
			cur->checkend = true;
		}
		else if (line[0] == '-' && line[1] == '-')								//checks if the string is the meaning or not
		{
			string mn;
			int len = line.length();
			int i = 2;
			while (i < len)						// skipping '-'
			{
				mn += line[i];					// storing string without '-'
				i++;
			}
			last->mean = mn;					// storing final product in tree
		}
		else if (line[0] != '-')last->synonyms.insert(line);				//checks if the string is synonym of word or not
	}
	file.close();								// closing file
}
bool TRIE::FindWord(string line)
{
	int len = line.length();
	node* cur = root;
	int i = 0;
	while (i < len)
	{
		int idx{};
		if (line[i] >= 'a' && line[i] <= 'z')idx = line[i] - 'a';				// fins suitable index for alphabet 
		else if (line[i] >= 'A' && line[i] <= 'Z')idx = line[i] - 'A';

		if (cur->word[idx] == NULL)return false;	// checks if node exists , if not then key dosent exist in tree and returns
		if (cur->word[idx]->alphabet == line[i])cur = cur->word[idx];
		i++;
	}
	if (cur->checkend == true)return true;	// returns true if key exist
	return false;
}
string TRIE::FindMeaning(string line)
{
	int len = line.length();
	node* cur = root;
	int i = 0;
	while (i < len)
	{
		int idx{};
		if (line[i] >= 'a' && line[i] <= 'z')idx = line[i] - 'a';
		else if (line[i] >= 'A' && line[i] <= 'Z')idx = line[i] - 'A';

		if (cur->word[idx] == NULL) i = len + 1;
		if (cur->word[idx]->alphabet == line[i])cur = cur->word[idx];		// traversing till end of key 
		i++;
	}
	if (cur->checkend == true)return cur->mean;			// returns meaning if key exist in tree
	return cur->mean;
}
Vector<string> TRIE::extract(string st , Vector<string>& t_words, node* rt)
{
	if (rt == NULL)	return t_words;		// base case
	else if (rt->checkend != true)st += rt->alphabet;			//storing values in string
	else if (rt->checkend == true)								// strorin gvalues in vector whe full word is retrived
	{
		st += rt->alphabet;
		t_words.insert(st);
	}
	for (int i = 0; i < 26; i++)extract(st, t_words, rt->word[i]);		// recursive call
	return t_words;
}
Vector<string> TRIE::OutputAscending()
{
	Vector<string> total_words;						// vector to store all words
	for (int i = 0; i < 26; i++)
	{
		string str;
		extract(str, total_words, root->word[i]);		// retrives words in ascending order
	}
	return total_words;
}
Vector<string> TRIE::OutputDescending()
{
	Vector<string> t_words;
	for (int i = 0; i < 26; i++)
	{
		string str;
		extract(str, t_words, root->word[i]);			//retrives words in ascending order
	}
	Vector<string> final;
	for (int i = t_words.Size()-1; i >=0; i--)	final.insert(t_words[i]); // reversing the vector
	return final;
}
Vector<string> TRIE::FindSynonyms(string line)
{
	int len = line.length();
	node* cur = root;
	int i = 0;
	while (i < len)
	{
		int idx{};
		if (line[i] >= 'a' && line[i] <= 'z')idx = line[i] - 'a';
		else if (line[i] >= 'A' && line[i] <= 'Z')idx = line[i] - 'A';

		if (cur->word[idx] == NULL) i=len+1;
		if (cur->word[idx]->alphabet == line[i])cur = cur->word[idx];		// traversing til the last node of key
		i++;
	}
	if (cur->checkend == true)return cur->synonyms;				// returning vector containing synonyms of key
	return cur->synonyms;
}
Vector<string> TRIE::OutputPrefix(string line)
{
	int len = line.length();
	Vector<string> prefix;
	node* cur = root;
	int i = 0;
	while (i < len)				// check if the key exist in tree or not
	{
		int idx{};
		if (line[i] >= 'a' && line[i] <= 'z')idx = line[i] - 'a';
		else if (line[i] >= 'A' && line[i] <= 'Z')idx = line[i] - 'A';

		if (cur->word[idx] == NULL)return prefix;
		if (cur->word[idx]->alphabet == line[i])cur = cur->word[idx];
		i++;
	}
	string str;
	for (int i = 0; i < line.size() - 1; i++)str += line[i];		// traversing in tree and retriving all prefixes 
	if (cur != NULL)extract(str , prefix,cur);
	return prefix;
}
Vector<string> TRIE::OutputSmaller(int length)
{
	Vector<string> total_words;
	Vector<string> final;
	for (int i = 0; i < 26; i++)			// retriving all words
	{
		string str;
		extract(str, total_words, root->word[i]);
	}
	for (int j = 0; j < total_words.Size();j++)			// storing smaller word in another vector
	{
		if (total_words[j].length() < length)final.insert(total_words[j]);
	}
	return final;
}
Vector<string> TRIE::OutputSE(int length)
{
	Vector<string> total_words;
	Vector<string> final;
	for (int i = 0; i < 26; i++)								//retriving words
	{
		string str;
		extract(str, total_words, root->word[i]);
	}
	for (int j = 0; j < total_words.Size() ; j++)				// storing greater and smaller words in vector
	{
		if (total_words[j].length() <= length)final.insert(total_words[j]);
	}
	return final;
}
Vector<string> TRIE::OutputGreater(int length)
{
	Vector<string> total_words;
	Vector<string> final;
	for (int i = 0; i < 26; i++)			// retriving words
	{
		string str;
		extract(str, total_words, root->word[i]);
	}
	for (int j = 0; j < total_words.Size() ;j++)			// stroing greater words in vector 
	{
		if (total_words[j].length() > length)final.insert(total_words[j]);
	}
	return final;
}
Vector<string> TRIE::OutputAnagrams(string str)
{
	Vector<string> total_words;
	Vector<string> anagrams;
	for (int i = 0; i < 26; i++)		// extracting words
	{
		string st;
		extract(st, total_words, root->word[i]);
	}
	for (int i = 0; i < total_words.Size(); i++)
	{
		string temp = total_words[i];
		if (temp != str && temp.length() == str.length())		// skipping the key and check if the size of key anf retrived word is same
		{
			int len = str.length();
			int k = 0;
			string found;
			while (k < len)
			{
				for (int j = 0; j < str.length(); j++)			// checking of both of string have same alphabets or not
				{
					if (temp[k] == str[j])found += temp[k];
				}
				if (found.length() == temp.length())anagrams.insert(temp);
				k++;
			}
		}
	}
	return anagrams;
}
Vector<string> TRIE::OutputSuffix(string str)
{
	Vector<string> suffix;
	Vector<string> total_words;
	for (int i = 0; i < 26; i++)			// retriving words from tree
	{
		string str;
		extract(str, total_words, root->word[i]);
	}
	for (int i = 0; i < total_words.Size(); i++)			// checking words one by one
	{
		string temp = total_words[i];
		int len = str.length()-1;
		int t_len = temp.length() - 1;
		int count = 0;
		while (len >= 0)									//checking either suffix exist or not
		{
			if (str[len] == temp[t_len])count++;
			len--;
			t_len--;
		}
		if (count == str.length())suffix.insert(temp);		// storing suffix in vector if exist
	}
	return suffix;
}
Vector<string> TRIE::CompleteString(string str)
{
	Vector<string> complete;
	Vector<string> total_words;
	for (int i = 0; i < 26; i++)			//retrinving words 
	{
		string str;
		extract(str, total_words, root->word[i]);
	}
	for (int i = 0; i < total_words.Size(); i++)		//checking word by word
	{
		string temp = total_words[i];
		int len = str.length();
		int count = 0;
		int t_len = temp.length();
		for (int j = 0; j < t_len; j++)						// checking if key exist in word or not
		{
			if (count < len && temp[j] == str[count])count++;	
		}
		if (count == len)complete.insert(temp);				// storing complete string in vector
	}
	return complete;
}
Vector<string> TRIE::SpellChecker(string str)
{
	Vector<string> total_words;
	Vector<string> spelling;
	for (int i = 0; i < 26; i++)				// retriving words
	{
		string st;
		extract(st, total_words, root->word[i]);
	}
	for (int i = 0; i < total_words.Size(); i++)
	{
		string temp = total_words[i];
		if (temp.length() - str.length() ==1)
		{
			if(temp[0] == str[0] && temp[str.length()] == str[str.length()-1])spelling.insert(temp);
		}
		else if (temp.length() == str.length())				// condition if spelling mistake 
		{
			int i = 0;
			int count = 0;
			while (i < temp.length())
			{
				if (temp[i] == str[i])count++;
				i++;
			}
			if (count == temp.length() - 1)spelling.insert(temp);
			
		}
		else if (temp.length() > str.length())				// condititon if alphabet is missing
		{
			int i = 0;
			int count = 0;
			while (i < temp.length())
			{
				if (temp[i] == str[count])
				{
					i++;
					count++;
				}
				else
				{
					i++;
				}
			}
			if (count == temp.length() - 1)spelling.insert(temp);
		}
	}
	return spelling;
}
#endif // !TRIE_H
