#ifndef VERTEX_H_
#define VERTEX_H_


#include<iostream>
using namespace std;


template <class A>
class Vertex
{

	public:

		A data;
		Vertex* next;
		Vertex();
		Vertex(A);

};


template <class A>
Vertex<A>::Vertex()
{
	next = NULL;
}


template <class A>
Vertex<A>::Vertex(A val)
{
	data = val;
	next = NULL;
}


#endif