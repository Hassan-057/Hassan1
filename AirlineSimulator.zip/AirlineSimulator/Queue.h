#ifndef QUEUE_H_
#define QUEUE_H_


#include "Vertex.h"


template <class A>
class Queue
{

	protected:
		Vertex<A>* first;
		Vertex<A>* last;

	public:
		
		Queue();
		Queue(A);
		~Queue();
		void enqueue(A);
		A dequeue();
		void clear();
		bool isEmpty() const;
		void display();
		bool find(A);

};


template<class A>
Queue<A>::Queue()
{
	first = NULL;
	last = NULL;
}


template<class A>
Queue<A>::Queue(A val)
{
	Vertex<A>* temp = new Vertex<A>();
	temp->data = val;
	first = temp;
	last = temp;
	last->next = NULL;
}


template<class A>
Queue<A>::~Queue()
{

}


template <class A>
void Queue<A>::enqueue(A val)
{
	Vertex<A>* temp = new Vertex<A>();
	temp->data = val;
	temp->next = NULL;

	if (first == NULL)
	{
		first = temp;
		last = temp;
		last->next = NULL;
	}
	else
	{
		last->next = temp;
		last = temp;
		last->next = NULL;
	}
	return;
}


template <class A>
A Queue<A>::dequeue()
{
	if (first != NULL)
	{
		Vertex<A>* temp = first;
		first = first->next;
		A data = temp->data;
		delete temp;
		return data;
	}
	else
	{
		cout << "Queue is empty.\n";
		return 0;
	}
}


template <class A>
void Queue<A>::clear()
{
	if (first != NULL)
	{
		Vertex<A>* temp = first;
		while (temp != NULL)
		{
			first = first->next;
			delete temp;
			temp = first;
		}
		first = NULL;
		last = NULL;
	}
	else
	{
		//cout << "Queue is empty.\n";
		return;
	}
}


template<class A>
bool Queue<A>::isEmpty() const
{
	if (first == NULL)
	{
		//cout << "Queue is empty.\n";
		return true;
	}
	else
	{
		//cout << "Queue is not empty.\n";
		return false;
	}
}


template <class A>
void Queue<A>::display()
{
	if (first == NULL)
	{
		//cout << "Queue is empty.\n";
		return;
	}
	else
	{
		Vertex<A>* temp = first;
		while (temp != NULL)
		{
			cout << temp->data << " ";
			temp = temp->next;
		}
		cout << endl;
		return;
	}
}


template <class A>
bool Queue<A>::find(A val)
{
	Vertex<A>* temp = first;
	while (temp != NULL)
	{
		if (temp->data == val)
		{
			return true;
		}
		temp = temp->next;
	}
	return false;
}
#endif